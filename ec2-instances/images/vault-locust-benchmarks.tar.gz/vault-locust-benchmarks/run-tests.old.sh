#!/bin/bash
while IFS=, read name datafile transtype  workers users spawn; do
  echo "$p" "name=$name" "datafile=$datafile" "transtype=$transtype" "users=$users" "spawn=$spawn"
  export TRANSFORM_TYPE=$transtype
  export DATA_FILE=$datafile
  # add --master back in after testing
  /usr/local/bin/locust --headless --expect-workers $workers --host http://127.0.0.1:8200 --users $users --spawn-rate $spawn --run-time 10s --csv-full-history -f=vault-transform-benchmarks.py --csv ./test-results/$name --html ./test-results/$name.html
done <vault-benchmarks-test-list.csv
