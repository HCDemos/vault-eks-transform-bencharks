import time, random, os 
from locust import HttpUser, task, between
from locust.contrib.fasthttp import FastHttpUser
from random import randint

#num = str(random.randint(10, 500))
#card_data = {"value" : "1111-2222-3333-4444"}
#class QuickstartUser(HttpUser):
DATA = '/home/ubuntu/vault-locust-benchmarks/test-data/' + os.getenv('DATA_FILE')
TRANSFORM_URL='/v1/transform/' + os.getenv('TRANSFORM_TYPE') + '/payments'
data_file = open(DATA,'r').read()
VAULT_TOKEN=os.getenv('VAULT_TOKEN')
#date_data = open('test-data/10k-ccnumstime-values.json','r').read()
#decimal_data = open('test-data/1k-decimal-random-values.json','r').read()
class QuickstartUser(FastHttpUser):
    #wait_time = between(1, 2.5)

    @task
    def my_task(self):
        self.client.post(TRANSFORM_URL, headers={"X-Vault-Token": VAULT_TOKEN}, data=data_file)

