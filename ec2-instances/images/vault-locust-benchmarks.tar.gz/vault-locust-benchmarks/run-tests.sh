#!/bin/bash
while IFS=, read name datafile transtype  workers users spawn; do
  echo "$p" "name=$name" "datafile=$datafile" "transtype=$transtype" "users=$users" "spawn=$spawn"
  export TRANSFORM_TYPE=$transtype
  export DATA_FILE=$datafile
  export FILENAME="${name}-${VAULT_EC2_CONFIG}"
  echo $TRANSFORM_TYPE > sshenv
  echo $DATA_FILE > sshenv
  echo $VAULT_TOKEN > sshenv
  # add --master back in after testing
  /home/ubuntu/.local/bin/locust --headless --master --expect-workers $workers --host $VAULT_ADDR --users $users --spawn-rate $spawn --run-time $RUN_TIME --csv-full-history -f=/home/ubuntu/vault-locust-benchmarks/vault-transform-benchmarks.py --csv /home/ubuntu/vault-locust-benchmarks/test-results/$FILENAME --html /home/ubuntu/vault-locust-benchmarks/test-results/$FILENAME.html &
  sleep 5s
  nohup ssh -o "StrictHostKeyChecking no" -i /home/ubuntu/vault-locust-benchmarks/key-ssh.pem ubuntu@$WORKER1 "VAULT_TOKEN=$VAULT_TOKEN TRANSFORM_TYPE=$TRANSFORM_TYPE DATA_FILE=$datafile /home/ubuntu/.local/bin/locust --worker --master-host=$LOCUST_MASTER -f=/home/ubuntu/vault-locust-benchmarks/vault-transform-benchmarks.py &" < /dev/null &
  #ssh -o "StrictHostKeyChecking no" -i /home/ubuntu/vault-locust-benchmarks/key-ssh.pem ubuntu@$WORKER1 "VAULT_TOKEN=$VAULT_TOKEN TRANSFORM_TYPE=$TRANSFORM_TYPE DATA_FILE=$datafile /home/ubuntu/.local/bin/locust --worker --master-host=$LOCUST_MASTER -f=/home/ubuntu/vault-locust-benchmarks/vault-transform-benchmarks.py &"
  sleep 5s
  nohup ssh -o "StrictHostKeyChecking no" -i /home/ubuntu/vault-locust-benchmarks/key-ssh.pem ubuntu@$WORKER2 "VAULT_TOKEN=$VAULT_TOKEN TRANSFORM_TYPE=$TRANSFORM_TYPE DATA_FILE=$datafile /home/ubuntu/.local/bin/locust --worker --master-host=$LOCUST_MASTER -f=/home/ubuntu/vault-locust-benchmarks/vault-transform-benchmarks.py &" < /dev/null &
  #ssh -o "StrictHostKeyChecking no" -i /home/ubuntu/vault-locust-benchmarks/key-ssh.pem ubuntu@$WORKER2 "VAULT_TOKEN=$VAULT_TOKEN TRANSFORM_TYPE=$TRANSFORM_TYPE DATA_FILE=$datafile /home/ubuntu/.local/bin/locust --worker --master-host=$LOCUST_MASTER -f=/home/ubuntu/vault-locust-benchmarks/vault-transform-benchmarks.py &"
  #ssh -i /home/ubuntu/key-aa16a308-6cb0-2a79-0988-217743772738.pem ubuntu@10.1.0.18 '/home/ubuntu/.local/bin/locust --worker --master=10.1.0.179 &' &
  echo "sleeping 90s to prepare for next test"
  sleep 90s
  now=$(date)
  echo "run for $name finished at $now - next run starting in 10s"
  sleep 10s
done < $VAULT_TEST_LIST_FILE