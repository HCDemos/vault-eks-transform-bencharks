import time
import os
from locust import HttpUser, task, between
from locust.contrib.fasthttp import FastHttpUser
import random
from random import randint
vaultToken=os.environ['VAULT_TOKEN']
testType = os.environ['testType']
testSize = os.environ['testSize']
testTransform = os.environ['testTransform']
testRole = os.environ['testRole']
postURL = "/v1/transform" + "/" + testType + "/" + testRole
print(postURL)
#num = str(random.randint(10, 500))
#card_data = {"value" : "1111-2222-3333-4444"}
#class QuickstartUser(HttpUser):
#card_data = open('1k-ccn-batch-transform.json','r').read()
testFile = "/home/ubuntu/test-data/" + testSize + "-" + testTransform + "-values.json"
date_data = open(testFile,'r').read()
class QuickstartUser(FastHttpUser):
    #wait_time = between(1, 2.5)

    @task
    def on_start(self):
        #num = str(random.randint(1000000000000000, 9999999999999999))
        #card_data = {"value" : num}
        #self.client.post("/v1/transform/encode/date-time", headers={"X-Vault-Token": vaultToken}, data=date_data)
        self.client.post(postURL, headers={"X-Vault-Token": vaultToken}, data=date_data)
        #print(card_data)

