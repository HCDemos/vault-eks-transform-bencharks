import time
from locust import HttpUser, task, between
from locust.contrib.fasthttp import FastHttpUser
import random
from random import randint

#num = str(random.randint(10, 500))
#card_data = {"value" : "1111-2222-3333-4444"}
#class QuickstartUser(HttpUser):
#card_data = open('1k-ccn-batch-transform.json','r').read()
date_data = open('/home/ubuntu/test-data/10k-date-time-values.json','r').read()
class QuickstartUser(FastHttpUser):
    #wait_time = between(1, 2.5)

    @task
    def on_start(self):
        #num = str(random.randint(1000000000000000, 9999999999999999))
        #card_data = {"value" : num}
        self.client.post("/v1/transform/encode/date-time", headers={"X-Vault-Token": "s.rcmtEmtNtsJ0A8MAegZfLUia"}, data=date_data)
        #print(card_data)

